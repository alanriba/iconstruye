﻿using System;
namespace IConstruye.Api.Model
{
    public class ControllerData
    {
        
            public string ControllerName { get; set; }
        public string ControllerActionName { get; set; }

    
    }
}

