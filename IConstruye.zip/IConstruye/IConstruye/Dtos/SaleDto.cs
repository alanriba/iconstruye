﻿using System.Diagnostics.CodeAnalysis;

namespace IConstruye.Dtos
{
    [ExcludeFromCodeCoverage]
    public class SaleDto
    {
        public int IdSlae { get; set; }
        public int IdClient { get; set; }
        public int idProduct { get; set; }
    }
}
