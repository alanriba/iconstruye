﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IConstruye.Utils.Enums
{
    public enum TipoServicio
    {
        GuardarProducto = 1,
        ListarProducto
    }
}
